from . import Mobile
from FSMs import WalkingFSM, AccelerationFSM
from utils import vec, RESOLUTION, magnitude, scale, EPSILON, normalize

from pygame.locals import *

import pygame
import numpy as np

from gameObjects import Drawable, Person


class Ghost(Mobile):
   def __init__(self, position, game):
      super().__init__(position, "ghost.png")
      self.game = game #we are passing the game object when initalizing ghost to access the Person's position later
      self.maxVelocity = 50

        
      # Animation variables specific to Person
      self.framesPerSecond = 2 
      self.nFrames = 2
      
      self.nFramesList = {
         "moving"   : 4,
         "standing" : 2
      }
      
      self.rowList = {
         "moving"   : 1,
         "standing" : 0
      }
      
      self.framesPerSecondList = {
         "moving"   : 8,
         "standing" : 2
      }
            
      self.FSManimated = WalkingFSM(self)
      self.LR = AccelerationFSM(self, axis=0)
      self.UD = AccelerationFSM(self, axis=1)
      
   def handleEvent(self, personPos):
      # if self.position[0] > personPos[0]: #if the ghost is to the right ofthe person
      #    print("ghost moving to the right")
      #    self.LR.increase()
      # elif self.position[0] < personPos[0]:
      #    print("ghost moving to the left")
      #    self.LR.decrease()
      # elif self.position[1] < personPos[1]:
      #    print("ghost moving up")
      #    self.UD.decrease()
      # elif self.position[1] > personPos[1]:
      #    print("ghost moving down")
      #    self.UD.increase()
      pass
     
   
   def update(self, seconds): 
      # self.LR.update(seconds)
      # self.UD.update(seconds)
      
      super().update(seconds)
      # Get the current position of the person
      person_position = self.game.person.position
      
      # Calculate the direction vector from the ghost to the person
      direction_to_person = person_position - self.position
      
      # Normalize the direction vector
      if magnitude(direction_to_person) > EPSILON:
         normalized_direction = normalize(direction_to_person)
      else:
         normalized_direction = vec(0, 0)  # Avoid division by zero
      
      # Update the ghost's velocity to move towards the person
      self.velocity = normalized_direction * self.maxVelocity


   def draw(self, drawSurface):
      super().draw(drawSurface)
  
   
   def updateMovement(self):
      pass