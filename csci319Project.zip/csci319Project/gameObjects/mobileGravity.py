from mobile import Mobile
from FSMs.gravity import GravityFSM
from FSMs.movement import AccelerationFSM
from utils.vector import vec


class MobileGravity(Mobile):
    def __init__(self, position, fileName=""):
        super().__init__(position, fileName)
        self.UD = GravityFSM(self)
        self.LR = AccelerationFSM(self)
        
    def update(self, seconds, collideRects):        
        self.UD.updateState()
        self.LR.updateState()   
 
        # Handle Collision with each item in colliders

        for collideRect in collideRects:
            if self.doesCollide(collideRect):

                pass
