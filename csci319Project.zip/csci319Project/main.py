import pygame
from UI import ScreenManager
from utils import RESOLUTION, UPSCALED

def main():
    #Initialize the module
    pygame.init()
    
    pygame.font.init()
    
    for i in range(pygame.joystick.get_count()):
        print(i)
        j = pygame.joystick.Joystick(i)
        if not j.get_init():
            j.init()
    
    #Get the screen
    screen = pygame.display.set_mode(list(map(int, UPSCALED)))
    drawSurface = pygame.Surface(list(map(int, RESOLUTION)))

    
    gameEngine = ScreenManager()
    
    RUNNING = True
    
    while RUNNING:

        
        gameEngine.draw(drawSurface)
        
        
        pygame.transform.scale(drawSurface,
                               list(map(int, UPSCALED)),
                               screen)
     
        pygame.display.flip()
        

        # personPos = gameEngine.game.getPersonPosition()
        # gameEngine.game.ghost.handleEvent(personPos)
        # print("ghost is moving towards", personPos)
        # Update the ghost's movement towards the person
        #gameEngine.game.ghost.update(seconds)
        
        # event handling, gets all event from the eventqueue
        for event in pygame.event.get():
            # only do something if the event is of type QUIT
            if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
                # change the value to False, to exit the main loop
                RUNNING = False
            else:
                result = gameEngine.handleEvent(event)
                
                if result == "exit":
                    RUNNING = False
        
        gameClock = pygame.time.Clock()
        gameClock.tick(60)
        seconds = gameClock.get_time() / 1000
        gameEngine.update(seconds)
     
    pygame.quit()


if __name__ == '__main__':
    main()