from FSMs import ScreenManagerFSM
from . import TextEntry, EventMenu
from utils import vec, RESOLUTION, WORLD_SIZE
# from gameObjects.engine import GameEngine
from gameObjects import Key
from engines.platformer import PlatformerGameEngine

from pygame.locals import *

class ScreenManager(object):
      
    def __init__(self):
        #self.game = GameEngine()
        self.game = PlatformerGameEngine()
        self.state = ScreenManagerFSM(self)
        self.pausedText = TextEntry(vec(0,0),"Paused")
        self.timer = 0
        self.timeLimit = 30
        self.fontSize =32
        self.leaderboard = []

        self.leaderBoardText = TextEntry(vec(0,0),"Leaderboard:")
        self.scoreText = TextEntry(vec(0,0),"seconds")
        lbmidpoint = RESOLUTION // 2 - vec(50,140)
        self.leaderBoardText.position = vec(*lbmidpoint)
        scoreMidpoint = RESOLUTION // 2 - vec(50,120)
        self.scoreText.position = vec(*scoreMidpoint)
        
        size = self.pausedText.getSize()
        midpoint = RESOLUTION // 2 - size
        self.pausedText.position = vec(*midpoint)
        
        self.mainMenu = EventMenu("backg2.png", fontName="default8")
        
        self.loseMenu = EventMenu("backg2.png", fontName="default8")
        self.loseText = TextEntry(vec(0,0), f"You lost in {self.timer:.1f} seconds")
        self.loseText.color=(255,255,255)
        # loseSize = self.loseText.getSize()
        lmidpoint = RESOLUTION // 2 - vec(95,30)
        self.loseText.position = vec(*lmidpoint)
        
        self.winMenu = EventMenu("backg2.png", fontName="default8")
        self.winText = TextEntry(vec(0,0), f"You won in {self.timer:.1f} seconds")
        self.winText.position = vec(*lmidpoint)
        
        self.mainMenu.addOption("start", "Press 1 to start Game", RESOLUTION // 2 - vec(0,50),
                         lambda x: x.type == KEYDOWN and x.key == K_1,
                         center="both")
        
        self.mainMenu.addOption("exit", "Press 2 to exit Game",
                                 RESOLUTION // 2 + vec(0,50),
                                 lambda x: x.type == KEYDOWN and x.key == K_2,
                                 center="both")
        
        self.loseMenu.addOption("start", "Press 1 to restart Game", RESOLUTION // 2 - vec(0,50),
                         lambda x: x.type == KEYDOWN and x.key == K_1,
                         center="both")
        
        self.winMenu.addOption("start", "Press 1 to restart Game", RESOLUTION // 2 - vec(0,50),
                         lambda x: x.type == KEYDOWN and x.key == K_1,
                         center="both")
    
    
    def draw(self, drawSurf):
        if self.state.isInGame():
            self.game.draw(drawSurf)
            if self.checkTimer():
                self.state.loseGame()
        
            if self.game.keyCount == 5:
                self.state.winGame()
            elif self.game.livesLeft <1:
                print("losing")
                self.state.loseGame()
                        
            if self.state == "paused":
                self.pausedText.draw(drawSurf)
        
        elif self.state == "mainMenu":
            self.mainMenu.draw(drawSurf)
        
        elif self.state == "gameOver":
            self.loseMenu.draw(drawSurf)
            self.loseText.color = (255,255,255)
            self.loseText.text = f"You lost in {self.timer:.1f} seconds"
            self.loseText.render()
            self.loseText.draw(drawSurf)
            self.leaderBoardText.draw(drawSurf)
            self.displayLeaderBoard(drawSurf)
        
        elif self.state == "victory":
            self.winMenu.draw(drawSurf)
            self.winText.text = f"You won in {self.timer:.1f} seconds"
            self.winText.render()
            self.winText.draw(drawSurf)
            self.displayLeaderBoard(drawSurf)
            
    
    def handleEvent(self, event):
        if self.state in ["game", "paused"]:
            if event.type == KEYDOWN and event.key == K_m:
                self.state.quitGame()
            elif event.type == KEYDOWN and event.key == K_p:
                self.state.pause()
                
            else:
                self.game.handleEvent(event)
        elif self.state == "mainMenu":
            choice = self.mainMenu.handleEvent(event)
            if choice == "start":
            # Reset game state before starting
                self.game.resetGame()
                self.timer = 0
                self.state.startGame()
            elif choice == "exit":
                return "exit"
            # print("choice", choice)
        elif self.state == "gameOver":
            choice = self.loseMenu.handleEvent(event)
            
            if choice == "start":
                # self.game.key1.position = Key(vec(250, WORLD_SIZE[1] - 210))
                self.game.resetGame()
                self.timer = 0
                self.state.loseGame()
            elif choice == "exit":
                return "exit"
            
        elif self.state == "victory":
            choice = self.loseMenu.handleEvent(event)
            
            if choice == "start":
                if len(self.leaderboard) < 3: #if there are less than 3 values in the leaderboard
                    self.leaderboard.append(round(self.timer,1))
                    self.leaderboard.sort()
                    # print(self.leaderboard)
                else:
                    self.leaderboard.sort()
                    if self.timer < self.leaderboard[len(self.leaderboard) -1]:
                        self.leaderboard[len(self.leaderboard) -1] = round(self.timer, 1)
                        self.leaderboard.sort()
                print(self.leaderboard)
                # self.game.key1.position = Key(vec(250, WORLD_SIZE[1] - 210))
                self.game.resetGame()
                self.timer = 0
                self.state.winGame()
            elif choice == "exit":
                return "exit"
     
    
    def update(self, seconds):      
        
        if self.state == "game":
            self.game.update(seconds)
            self.timer += seconds
            # currentTime = self.timer
            self.game.timertText.text = f"Countdown: {(self.timeLimit-self.timer):.1f}"
            self.game.timertText.render()
            # print("time:", f"Time elapsed: {self.timer:.1f}")
        elif self.state == "mainMenu":
            self.mainMenu.update(seconds)
            # self.timer = 0
        elif self.state == "gameOver":
            
            self.loseMenu.update(seconds)
            # self.timer = 0
        self.checkTimer()

    def checkTimer(self):
        if self.timer >= self.timeLimit:
            return True
        
    def displayLeaderBoard(self, drawSurf):
        self.leaderBoardText.draw(drawSurf)

        for i, time in enumerate(self.leaderboard[:3]):
            self.scoreText.position[1] = 50 + i*20 #space out scores evenly
            # vec(100, 100 + i * 20)  # Adjust position based on your layout
            self.scoreText.text = f"{i + 1}. {time} seconds"
            self.scoreText.render()
            self.scoreText.draw(drawSurf)

    