from gameObjects import Drawable
from utils import vec
import pygame
import os

class TextEntry(Drawable):   
    if not pygame.font.get_init():
        pygame.font.init()
    
    FONT_FOLDER = "fonts" 
    DEFAULT_FONT = "PressStart2P.ttf"
    DEFAULT_SIZE = 8   
    FONTS = {
       "default" : pygame.font.Font(os.path.join(FONT_FOLDER,
                                    DEFAULT_FONT), DEFAULT_SIZE),
       "default8" : pygame.font.Font(os.path.join(FONT_FOLDER,
                                    DEFAULT_FONT), 8)
    }
  
    def __init__(self, position, text, font="default",
              color= (255, 255, 255)):
        super().__init__(position, "")
        self.color = color
        self.text = text
        self.font = font
        self.camera_offset = vec(0, 0)  # make offset 0 so that the text stays in the same position on the screen
        self.render()


    def render(self):
        self.image = TextEntry.FONTS[self.font].render(self.text,
                                             False, self.color)
        
    def draw(self, drawSurface):
        drawSurface.blit(self.image, self.position - self.camera_offset) 
        