from gameObjects import Person, Drawable, Ghost, Key
from UI import TextEntry
from utils import vec, RESOLUTION, WORLD_SIZE
import pygame
import time

class PlatformerGameEngine(object):
    def __init__(self):
        # Initialize game objects (Person character, platforms, etc.)
        self.person = Person(vec(16, WORLD_SIZE[1] - 80))
        self.ghost = Ghost((250,50), self)
        self.ghost2 = Ghost((-50, -50), self)
        self.ghost.maxVelocity = 50
        #self.key = Drawable(vec(220, WORLD_SIZE[1] - 120), "keya.png")
        self.key1 = Key(vec(250, WORLD_SIZE[1] - 210))
        self.key2 = Key(vec(150, WORLD_SIZE[1] - 110))
        self.key3 = Key(vec(320, WORLD_SIZE[1] - 130))
        self.key4 = Key(vec(30, WORLD_SIZE[1] - 150))
        self.key5 = Key(vec(520, WORLD_SIZE[1] - 170))
        self.keys = [self.key1, self.key2, self.key3,self.key4,self.key5]
        self.platforms = []  # List to store platform tiles
        self.jumpingBlocks = []
        self.loadPlatforms()  # Load platform tiles

        # Create counting variables
        self.keyCount = 0
        self.livesLeft = 3

        # Create TextEntry objects for counts
        self.keyCountText = TextEntry(vec(10, 10), "Keys collected: 0") #Key count
        self.livesLeftText = TextEntry(vec(10, 30), "Lives left: 3") #Life count
        self.timertText = TextEntry(vec(10, 50), "Time elapsed: 0") #Timer
        
        self.attackCooldown = 20  # Cooldown time in seconds
        self.lastAttackTime = 0  # Initialize last attack time
        self.attackTimer = 0
        
        

    def loadPlatforms(self):
        # Define positions for platform tiles (example positions)
        lowestHeight = WORLD_SIZE[1] - 32
        platform_positions = [
            vec(0, lowestHeight),
            vec(100, lowestHeight),
            vec(200, lowestHeight),
            vec(300, lowestHeight),
            vec(400, lowestHeight),
            vec(500, lowestHeight),
            vec(600, lowestHeight),

            # Add more positions as needed
        ]

        platform_positions2 = [  #tiny platforms
            vec(100, WORLD_SIZE[1] - 70),
            vec(200, WORLD_SIZE[1] - 100),
            vec(250, WORLD_SIZE[1] - 150),
            vec(300, WORLD_SIZE[1] - 100),
            vec(400, WORLD_SIZE[1] - 70),
            vec(350, WORLD_SIZE[1] - 200),
            vec(450, WORLD_SIZE[1] - 250),
            vec(0, WORLD_SIZE[1] - 100 ),
            vec(530, WORLD_SIZE[1] - 70),
            vec(500, WORLD_SIZE[1] - 130),

            

            # Add more positions as needed
        ]


        self.background = Drawable((0,0), "backg2.png")
        # Create Drawable objects for platform tiles and add them to the list
        for pos in platform_positions: #big platforms
            platform = Drawable(pos, "dungeonBrick.png")  # Assuming "dungeonBrick.png" is the image of bricks
            platform.image = pygame.transform.scale(platform.image, vec(100,20) )
            self.platforms.append(platform)
        
        for pos in platform_positions2: #small jumping blocks
            platform = Drawable(pos, "dungeonBrick.png")  # Assuming "dungeonBrick.png" is the image of bricks
            platform.image = pygame.transform.scale(platform.image, vec(50,20) )
            self.jumpingBlocks.append(platform)

        for platform in self.jumpingBlocks:
            self.platforms.append(platform)
        # self.key.image = pygame.transform.scale(self.key.image, vec(20,20) )

    def draw(self, drawSurface):
        # Draw everything including platform tiles
        
        self.background.draw(drawSurface)
        for platform in self.platforms:
            platform.draw(drawSurface)
        # pygame.draw.rect(drawSurface, (255, 0, 0), platform.getCollisionRect(), 2)  # Draw collision rect
        # for platform in self.jumpingBlocks:
        #     platform.draw(drawSurface)
        self.person.draw(drawSurface)
        # pygame.draw.rect(drawSurface, (255, 0, 0), self.person.getCollisionRect(), 2)  # Draw person's collision rect
        self.ghost.draw(drawSurface)
        # pygame.draw.rect(drawSurface, (200,0,0), self.ghost.getCollisionRect(), 2)

        #self.key.draw(drawSurface)
        # self.key2.draw(drawSurface)
        self.ghost2.draw(drawSurface)
        # pygame.draw.rect(drawSurface, (255, 0, 0), self.key2.getCollisionRect(), 2)  # Draw key2's collision rect
        foot_rect = pygame.Rect(self.person.position[0], self.person.position[1] +
                                 self.person.getCollisionRect().height, self.person.getCollisionRect().width, 2)
        # pygame.draw.rect(drawSurface, (0,255,0), foot_rect, 2)
        self.keyCountText.draw(drawSurface)
        self.livesLeftText.draw(drawSurface)
        for key in self.keys:
            key.draw(drawSurface)
        self.keyCountText.draw(drawSurface)
        self.livesLeftText.draw(drawSurface)
        self.timertText.draw(drawSurface)

        

    def handleEvent(self, event):
        self.person.handleEvent(event)

    def update(self, seconds):
        self.person.update(seconds) #edited
        self.ghost.update(seconds)
        self.ghost2.update(seconds)
        Drawable.updateOffset(self.person, WORLD_SIZE)
        Drawable.updateOffset(self.ghost, WORLD_SIZE)
        self.checkCollision()
        self.checkKeyCollection()
        self.checkHasFallen()
        self.ghostAttack()
        # self.ghostAttackCooldown(seconds)
        

    def getPersonPosition(self): #returns the person's position so the ghost can follow
        return self.person.position
    
    def getPlCollisionRect(self, platform):
        return pygame.Rect(platform.position[0], platform.position[1], platform.getSize()[0], platform.getSize()[1])
    
    def getFootRect(self):
        return pygame.Rect(self.person.position[0], self.person.position[1] +
                                 self.person.getCollisionRect().height, self.person.getCollisionRect().width, 2)
    
    def checkCollision(self):
        person_rect = self.person.getCollisionRect()  # Get collision rectangle for the player
        for platform in self.platforms:
            platform_rect = self.getPlCollisionRect(platform)  # Get collision rectangle for each platform
            if person_rect.colliderect(platform_rect):  # Check for collision
                # Handle collision based on your game logic (e.g., stop player movement)
                self.person.handleCollision(platform)
    
    def checkHasFallen(self):
        foot_rect = self.getFootRect()
        #print("Foot Rect:", foot_rect)  # Debug print
        collided = False
        for platform in self.platforms:
            platform_rect = self.getPlCollisionRect(platform)  # Get collision rectangle for each platform
            # print("Platform Rect:", platform_rect)  # Debug print
            if foot_rect.colliderect(platform_rect):  # Check for collision
                self.person.isGrounded = True
                # print("in platformer:", self.person.isGrounded)
                collided = True
                break
        if not collided:
            self.person.isGrounded = False
            # print("after loop:", self.person.isGrounded)
            self.person.handleFalling()
                #print("checkHasFallen")            

    def checkKeyCollection(self):
        for key in self.keys:
            if self.person.getCollisionRect().colliderect(key.getCollisionRect()):
                self.person.collectKey()
                key.hide()
                print("Collected the Key!")
                self.keyCount += 1
                self.keyCountText.text = f"Keys collected: {self.keyCount}"  # Update text
        self.keyCountText.render()
    
    def ghostAttack(self):
        ghostRect = self.ghost.getCollisionRect()
        personRect = self.person.getCollisionRect()
        if time.time() - self.attackTimer >= self.attackCooldown:
            if personRect.colliderect(ghostRect) or personRect.colliderect(self.ghost2.getCollisionRect()):
                if self.livesLeft > 0:
                    self.livesLeft -= 1
                    self.livesLeftText.text = f"Lives left: {self.livesLeft}"  # Update text
                    self.livesLeftText.render()
                    self.person.velocity = vec(0,0)
                    self.person.LR.stop_all()
                    self.person.position = vec(16, WORLD_SIZE[1] - 72)
                    self.ghost.position = vec(-50, -50)
                    self.ghost2.position = vec(500, 0)
                    # self.lastAttackTime = time.time()
                else: 
                    pass #handle death


    def resetGame(self):
        self.key1.position = vec(250, WORLD_SIZE[1] - 210) #draw the keys in original positions when starting
        self.key2.position = vec(150, WORLD_SIZE[1] - 110)
        self.key3.position = vec(320, WORLD_SIZE[1] - 130)
        self.key4.position = vec(30, WORLD_SIZE[1] - 150)
        self.key5.position  = vec(520, WORLD_SIZE[1] - 170)
        self.ghost.position = (250,50)
        self.ghost2.position = (-50, -50)
        self.person.position = vec(16, WORLD_SIZE[1] - 80)
        self.person.velocity = vec(0,0)
        self.person.LR.stop_all()
        self.person.UD.fall()
        self.keyCount = 0
        self.keyCountText.text = f"Keys collected: {self.keyCount}"
        self.livesLeft = 3
        self.livesLeftText.text = f"Lives left: {self.livesLeft}"
        self.livesLeftText.render()
        self.keys = [self.key1, self.key2, self.key3, self.key4,self.key5]


# self.game.resetGame()
#                 self.state.startGame()
#         elif self.state == "gameOver":
#             choice = self.loseMenu.handleEvent(event)
#             if choice == "start":
#                 self.state.loseGame()
#             elif choice == "exit":
#                 return "exit"