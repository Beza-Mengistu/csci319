from . import Mobile
from FSMs import WalkingFSM, AccelerationFSM
from utils import vec, RESOLUTION, magnitude, scale, EPSILON, normalize

from pygame.locals import *

import pygame
import numpy as np

from gameObjects import Drawable, Person


class Ghost(Mobile):
   def __init__(self, position, game):
      super().__init__(position, "ghost.png")
      self.game = game #we are passing the game object when initalizing ghost to access the Person's position later
      self.maxVelocity = 70
      self.facingLeft = False

        
      # Animation variables specific to Person
      self.framesPerSecond = 2 
      self.nFrames = 2
      
      self.nFramesList = {
         "moving"   : 4,
         "standing" : 2
      }
      
      self.rowList = {
         "moving"   : 1,
         "standing" : 0
      }
      
      self.framesPerSecondList = {
         "moving"   : 8,
         "standing" : 2
      }
            
      self.FSManimated = WalkingFSM(self)
      self.LR = AccelerationFSM(self, axis=0)
      self.UD = AccelerationFSM(self, axis=1)
      
   def handleEvent(self, personPos):
      pass
     
   
   def update(self, seconds): 
      
      super().update(seconds)
      # Get the current position of the person
      person_position = self.game.person.position

      # Calculate the direction vector from the ghost to the person
      direction_to_person = person_position - self.position
      
      # Normalize the direction vector
      if magnitude(direction_to_person) > 5:
         normalized_direction = normalize(direction_to_person)
      else:
         normalized_direction = vec(0, 0)  # Avoid division by zero
      
      # Update the ghost's velocity to move towards the person
      self.velocity = normalized_direction * self.maxVelocity
      if self.velocity[0] > 0 and not self.facingLeft:
            # Flip the ghost's image horizontally
            self.image = pygame.transform.flip(self.image, True, False)
            self.facingLeft = True
      elif self.velocity[0] < 0 and self.facingLeft:
         # Flip the ghost's image back to original direction
         self.image = pygame.transform.flip(self.image, True, False)
         self.facingLeft = False


   def draw(self, drawSurface):
      super().draw(drawSurface)
  
   
   def updateMovement(self):
      pass

   def getCollisionRect(self):
        # Customize the collision rectangle size for the ghost
        rect_width = self.getSize()[0] // 1
        rect_height = self.getSize()[1] // 1.1
        new_rect = pygame.Rect(self.position[0], self.position[1], rect_width, rect_height)
        return new_rect