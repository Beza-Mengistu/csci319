from . import Mobile
from FSMs.gravity import GravityFSM
from FSMs.movement import AccelerationFSM
from utils.vector import vec


class MobileGravity(Mobile):
    def __init__(self, position, fileName=""):
        super().__init__(position, fileName)
        self.UD = GravityFSM(self)
        self.LR = AccelerationFSM(self)
        
    def update(self, seconds):        
        self.UD.updateState()
        self.LR.updateState()   
 
        # Update position based on velocity after handling collision
        self.position += self.velocity * seconds
