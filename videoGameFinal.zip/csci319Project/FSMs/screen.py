from . import AbstractGameFSM
from statemachine import State
# from UI import TextEntry, vec


class ScreenManagerFSM(AbstractGameFSM):
    mainMenu = State(initial=True)
    game     = State()
    paused   = State()
    gameOver = State()
    victory = State()
    
    pause = game.to(paused) | paused.to(game) | \
            mainMenu.to.itself(internal=True)
    
    startGame = mainMenu.to(game)
    quitGame  = game.to(mainMenu) | \
                paused.to.itself(internal=True)
    loseGame = game.to(gameOver) | gameOver.to(game)

    winGame = game.to(victory) | victory.to(game)
    

    def isInGame(self):
        return self == "game" or self == "paused"
    


    
    