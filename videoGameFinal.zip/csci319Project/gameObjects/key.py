import pygame
from gameObjects import Drawable

class Key(Drawable):
    def __init__(self, position):
        super().__init__(position, "keyCopy.png")
        self.collected = False
        
        
    def update(self, seconds):
        pass

    def draw(self, draw_surface):
        
        #if not self.collected:
        super().draw(draw_surface)
    
    def hide(self):
        self.position = (-100,-100)
        self.collected = True