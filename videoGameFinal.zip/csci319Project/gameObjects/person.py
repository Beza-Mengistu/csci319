from . import Mobile
from FSMs import WalkingFSM, AccelerationFSM, GravityFSM
from utils import vec, RESOLUTION

from pygame.locals import *

import pygame
import numpy as np

from gameObjects import Drawable, MobileGravity


#class Person(Mobile):
class Person(MobileGravity):
   def __init__(self, position):
      super().__init__(position, "person.png")

        
      # Animation variables specific to Person
      self.framesPerSecond = 2 
      self.nFrames = 2
      
      self.nFramesList = {
         "moving"   : 4,
         "standing" : 2
      }
      
      self.rowList = {
         "moving"   : 1,
         "standing" : 0
      }
      
      self.framesPerSecondList = {
         "moving"   : 8,
         "standing" : 2
      }
            
      self.FSManimated = WalkingFSM(self)
      self.LR = AccelerationFSM(self, axis=0)
      #self.UD = AccelerationFSM(self, axis=1)
      self.UD = GravityFSM(self)
      self.collectedKey = False #will change this to true when Person collides with Key
      self.isGrounded = False
      
   def handleEvent(self, event):
      if event.type == KEYDOWN:
         if event.key == K_UP:
            #self.UD.decrease()
            self.UD.jump()
             
         elif event.key == K_DOWN:
            #self.UD.increase()
            pass
            
         elif event.key == K_LEFT:
            self.LR.decrease()
            
         elif event.key == K_RIGHT:
            self.LR.increase()
         # print("****type:", event.type,"key:", event.key)
            
      elif event.type == KEYUP:
         if event.key == K_UP:
            # self.UD.stop_decrease()
            if self.UD.canFall:
               self.UD.fall()
            else:
               pass
             
         elif event.key == K_DOWN:
            # self.UD.stop_increase()
            pass
            
         elif event.key == K_LEFT:
            self.LR.stop_decrease()
            
         elif event.key == K_RIGHT:
            self.LR.stop_increase()
         # print("****type:", event.type,"key:", event.key)
   
   def update(self, seconds): 
      self.LR.update(seconds)
      self.UD.update(seconds)
      ##collecting key when person collides
      super().update(seconds)


   def draw(self, drawSurface):
      super().draw(drawSurface)
  
   
   def updateMovement(self):
      pass

   def getCollisionRect(self):
        # Customize the collision rectangle size for the person
        rect_width = self.getSize()[0] // 1
        rect_height = self.getSize()[1] // 1.1
        new_rect = pygame.Rect(self.position[0], self.position[1], rect_width, rect_height)
        return new_rect

   def collectKey(self):
      self.collectedKey = True


   def handleCollision(self, platform):
      person_rect = self.getCollisionRect()
      platform_rect = pygame.Rect(platform.position[0], platform.position[1], platform.getSize()[0], platform.getSize()[1])
      foot_rect = pygame.Rect(self.position[0], self.position[1] + person_rect.height, person_rect.width, 4)

      if person_rect.colliderect(platform_rect):
         collisionArea = platform_rect.clip(person_rect)
         if collisionArea[2] > collisionArea[3]:
            if platform.position[1] > self.position[1]: #[x,y]
                  if self.velocity[1] > 0:
                     self.UD.land()
                     self.velocity[1] = 0
                     self.position[1] -= collisionArea[3]
            else: #if the platform is above the person
   #                # print("from below, y-coordinate of platform and person:", platform.position[1], self.position[1])
                  if self.velocity[1] < 0:  # Stop vertical movement
                     self.UD.land()  # Stop downward movement
                     self.velocity[1] = 0
                     self.position[1] += collisionArea[3]
            
         else:
            if platform.position[0] > self.position[0]:
                  if self.velocity[0] > 0:
                     self.LR.stop_increase()
                     self.velocity[0] = 0
                     self.position[0] -= collisionArea[2]
            elif platform.position[0] < self.position[0]:
                  if self.velocity[0] < 0:
                     self.LR.stop_decrease()
                     self.position[0] += collisionArea[2]
      else:
         print("not colliding")
         self.isGrounded = False
         self.UD.fall()
   
   
   def handleFalling(self):
      person_rect = self.getCollisionRect()
      if self.isGrounded:
         self.UD.land()  # Land on the platform
      else:
         self.UD.fall()